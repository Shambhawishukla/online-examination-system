<?php
//all the variables defined here are accessible in all the files that include this one
$con= new mysqli('localhost','root','','project1')or die("Could not connect to mysql".mysqli_error($con));

?>